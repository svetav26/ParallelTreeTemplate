#pragma once
void delete_matrix(int**& a, int N);
bool gamilton(int v0, int** a, int N, int* visit, int* jump);
int Gam(int v0, int N, int** a, int* jump, int* visit);

